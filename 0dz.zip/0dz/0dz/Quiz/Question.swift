//
//  Question.swift
//  0dz
//
//  Created by Toma Sikora on 11/04/2019.
//  Copyright © 2019 Toma Sikora. All rights reserved.
//

import Foundation

class Question {
    let question: String
    let id: Int
    let answers: [String]
    let correct: Int
    
    init?(questions:[String: Any]) {
        if let id = questions["id"] as? Int,
            let question = questions["question"] as? String,
            let answers = questions["answers"] as? [String],
            let correct = questions["correct_answer"] as? Int{
            self.id = id
            self.question = question
            self.answers = answers
            self.correct = correct
        } else {
            return nil
        }
    }
}
