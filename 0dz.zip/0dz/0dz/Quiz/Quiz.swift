//
//  Quiz.swift
//  0dz
//
//  Created by Toma Sikora on 11/04/2019.
//  Copyright © 2019 Toma Sikora. All rights reserved.
//

import Foundation
import UIKit

class Quiz {
    let id: Int
    let title: String
    let description: String
    let category: Category
    let level: Int
    let imageURL: String
    let questions: [Question]
    
    
    init?(quiz: [String: Any]) {
        if let id = quiz["id"] as? Int,
            let title = quiz["title"] as? String,
            let description = quiz["description"] as? String,
            let category = quiz["category"] as? String,
            let level = quiz["level"] as? Int,
            let imageURL = quiz["image"] as? String,
            let qs = quiz["questions"] as? [[String: Any]]{
            self.id = id
            self.title = title
            self.description = description
            self.category =  category=="SPORTS" ?  Category.SPORTS("SPORTS"):Category.SCIENCE("SCIENCE")
            self.level = level
            self.imageURL = imageURL
            var ques = [Question?](repeating: nil, count: qs.count)
            var i = 0
            while i<qs.count{
                ques[i]=Question(questions: qs[i])
                i += 1
            }
            self.questions = ques as! [Question]
        } else {
            return nil
        }
    }
}
