//
//  Category.swift
//  0dz
//
//  Created by Toma Sikora on 11/04/2019.
//  Copyright © 2019 Toma Sikora. All rights reserved.
//

import Foundation
import UIKit


enum Category{
    case SPORTS(String)
    case SCIENCE(String)
    
    var colour: String {
        switch self {
        case .SPORTS:
                return "BLUE"
        case .SCIENCE:
                return "GREEN"
        }
    }
    
    var UIcolour: UIColor {
        switch self {
        case .SPORTS:
            return UIColor.blue
        case .SCIENCE:
            return UIColor.green
        }
    }
    
    var code: String {
        switch self {
        case .SCIENCE(let val):
            return val
        case .SPORTS(let val):
            return val
        }
    }
    
    var text: String {
        switch self {
        case .SPORTS:
            return "Sports"
        case .SCIENCE:
            return "Science"
        }
    }
}
