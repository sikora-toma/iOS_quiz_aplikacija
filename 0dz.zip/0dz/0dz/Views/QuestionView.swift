//
//  QuestionView.swift
//  0dz
//
//  Created by Toma Sikora on 11/04/2019.
//  Copyright © 2019 Toma Sikora. All rights reserved.
//

import Foundation
import UIKit

class QuestionView: UIView {
    
    var questionLabel: UILabel?
    var aButton: UIButton?
    var bButton: UIButton?
    var cButton: UIButton?
    var dButton: UIButton?
    var correct: Int
    
    override init(frame: CGRect) {
        correct = 0
        super.init(frame: frame)
        
        questionLabel = UILabel(frame: CGRect(origin: CGPoint(x: 10, y: 10), size: CGSize(width: 280, height: 20)))
        questionLabel?.text = "text"
        questionLabel?.adjustsFontSizeToFitWidth = true
        questionLabel?.backgroundColor = UIColor.white
        
        aButton = UIButton(frame: CGRect(origin: CGPoint(x: 10, y: 40), size: CGSize(width: 135, height: 20)))
        bButton = UIButton(frame: CGRect(origin: CGPoint(x: 155, y: 40), size: CGSize(width: 135, height: 20)))
        cButton = UIButton(frame: CGRect(origin: CGPoint(x: 10, y: 70), size: CGSize(width: 135, height: 20)))
        dButton = UIButton(frame: CGRect(origin: CGPoint(x: 155, y: 70), size: CGSize(width: 135, height: 20)))
        
        aButton?.titleLabel?.adjustsFontSizeToFitWidth = true
        bButton?.titleLabel?.adjustsFontSizeToFitWidth = true
        cButton?.titleLabel?.adjustsFontSizeToFitWidth = true
        dButton?.titleLabel?.adjustsFontSizeToFitWidth = true
        
        
        aButton?.setTitleColor(UIColor.black, for: .normal)
        bButton?.setTitleColor(UIColor.black, for: .normal)
        cButton?.setTitleColor(UIColor.black, for: .normal)
        dButton?.setTitleColor(UIColor.black, for: .normal)
        
        aButton?.setTitle("a", for: .normal)
        bButton?.setTitle("b", for: .normal)
        cButton?.setTitle("c", for: .normal)
        dButton?.setTitle("d", for: .normal)
        
        aButton?.backgroundColor = UIColor.white
        bButton?.backgroundColor = UIColor.white
        cButton?.backgroundColor = UIColor.white
        dButton?.backgroundColor = UIColor.white
        
        aButton?.addTarget(self, action: #selector(buttonAction), for: .touchUpInside)
        bButton?.addTarget(self, action: #selector(buttonAction), for: .touchUpInside)
        cButton?.addTarget(self, action: #selector(buttonAction), for: .touchUpInside)
        dButton?.addTarget(self, action: #selector(buttonAction), for: .touchUpInside)
        
        
        if let label = questionLabel {
            self.addSubview(label)
        }
        if let aButton = aButton{
            self.addSubview(aButton)
        }
        if let bButton = bButton{
            self.addSubview(bButton)
        }
        if let cButton = cButton{
            self.addSubview(cButton)
        }
        if let dButton = dButton{
            self.addSubview(dButton)
        }
        
        self.backgroundColor = UIColor.darkGray
    }
    
    // Ovaj init se poziva kada se CustomView inicijalizira iz .xib datoteke
    required init?(coder aDecoder: NSCoder) {
        correct = 0
        super.init(coder: aDecoder)
        
        questionLabel = UILabel(frame: CGRect(origin: CGPoint(x: 10, y: 10), size: CGSize(width: 280, height: 20)))
        questionLabel?.text = "text"
        questionLabel?.adjustsFontSizeToFitWidth = true
        questionLabel?.backgroundColor = UIColor.white
        
        
        aButton = UIButton(frame: CGRect(origin: CGPoint(x: 10, y: 40), size: CGSize(width: 135, height: 20)))
        bButton = UIButton(frame: CGRect(origin: CGPoint(x: 155, y: 40), size: CGSize(width: 135, height: 20)))
        cButton = UIButton(frame: CGRect(origin: CGPoint(x: 10, y: 70), size: CGSize(width: 135, height: 20)))
        dButton = UIButton(frame: CGRect(origin: CGPoint(x: 155, y: 70), size: CGSize(width: 135, height: 20)))
        
        aButton?.titleLabel?.adjustsFontSizeToFitWidth = true
        bButton?.titleLabel?.adjustsFontSizeToFitWidth = true
        cButton?.titleLabel?.adjustsFontSizeToFitWidth = true
        dButton?.titleLabel?.adjustsFontSizeToFitWidth = true
        
        aButton?.setTitleColor(UIColor.black, for: .normal)
        bButton?.setTitleColor(UIColor.black, for: .normal)
        cButton?.setTitleColor(UIColor.black, for: .normal)
        dButton?.setTitleColor(UIColor.black, for: .normal)
        
        aButton?.setTitle("a", for: .normal)
        bButton?.setTitle("b", for: .normal)
        cButton?.setTitle("c", for: .normal)
        dButton?.setTitle("d", for: .normal)
        
        aButton?.backgroundColor = UIColor.white
        bButton?.backgroundColor = UIColor.white
        cButton?.backgroundColor = UIColor.white
        dButton?.backgroundColor = UIColor.white
        
        
        if let label = questionLabel {
            self.addSubview(label)
        }
        if let aButton = aButton{
            self.addSubview(aButton)
        }
        if let bButton = bButton{
            self.addSubview(bButton)
        }
        if let cButton = cButton{
            self.addSubview(cButton)
        }
        if let dButton = dButton{
            self.addSubview(dButton)
        }
        
    }
    
    @objc func buttonAction(_ sender: UIButton!){
        if sender.currentTitle == aButton?.currentTitle && correct==0
            || sender.currentTitle == bButton?.currentTitle && correct==1
            || sender.currentTitle == cButton?.currentTitle && correct==2
             || sender.currentTitle == dButton?.currentTitle && correct==3
        {
            sender?.backgroundColor = UIColor.green
        } else {
            sender.backgroundColor = UIColor.red
        }
    }
    
    
    func setQ(question: Question){
        DispatchQueue.main.async {
            self.questionLabel?.text = question.question
            self.aButton?.setTitle(question.answers[0], for: .normal)
            self.bButton?.setTitle(question.answers[1], for: .normal)
            self.cButton?.setTitle(question.answers[2], for: .normal)
            self.dButton?.setTitle(question.answers[3], for: .normal)
            
            self.aButton?.backgroundColor = UIColor.white
            self.bButton?.backgroundColor = UIColor.white
            self.cButton?.backgroundColor = UIColor.white
            self.dButton?.backgroundColor = UIColor.white
        }
        correct = question.correct
    }
    
    
}
