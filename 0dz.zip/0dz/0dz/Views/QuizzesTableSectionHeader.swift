//
//  ReviewsTableSectionHeader.swift
//  TableViewDemo
//
//  Created by Josip Maric on 06/05/2019.
//  Copyright © 2019 Josip Maric. All rights reserved.
//

import UIKit

class QuizzesTableSectionHeader: UIView {

    var titleLabel: UILabel!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        backgroundColor = UIColor.lightGray
        titleLabel = UILabel()
        titleLabel.text = "Quizzes"
        titleLabel.font = UIFont.systemFont(ofSize: 20)
        titleLabel.textColor = UIColor.darkGray
        self.addSubview(titleLabel)
        //titleLabel.autoPinEdge(.top, to: .top, of: self, withOffset: 16.0)
        //titleLabel.autoAlignAxis(.horizontal, toSameAxisOf: self)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
