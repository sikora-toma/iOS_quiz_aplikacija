//
//  LoginView.swift
//  0dz
//
//  Created by Toma Sikora on 06/05/2019.
//  Copyright © 2019 Toma Sikora. All rights reserved.
//

import Foundation
import  UIKit

class LoginView: UIView {
    
    var usernameLabel: UILabel?
    var passwordLabel: UILabel?
    var usernameText: UITextField?
    var passwordText: UITextField?
    var loginButton: UIButton?
    var correct: Int
    
    override init(frame: CGRect) {
        correct = 0
        super.init(frame: frame)
        
        usernameLabel = UILabel(frame: CGRect(origin: CGPoint(x: 20, y: 20), size: CGSize(width: 280, height: 20)))
        usernameLabel?.text = "Username:"
        usernameLabel?.adjustsFontSizeToFitWidth = true
        usernameLabel?.backgroundColor = UIColor.white
        
        passwordLabel = UILabel(frame: CGRect(origin: CGPoint(x: 20, y: 70), size: CGSize(width: 100, height: 20)))
        passwordLabel?.text = "Password:"
        passwordLabel?.adjustsFontSizeToFitWidth = true
        passwordLabel?.backgroundColor = UIColor.white
        
        usernameText = UITextField(frame: CGRect(origin: CGPoint(x: 20, y: 40), size: CGSize(width: 200, height: 20)))
        usernameText?.borderStyle = .roundedRect
        usernameText?.placeholder = "Insert username"
        usernameText?.layer.borderColor = UIColor.black.cgColor
        usernameText?.layer.borderWidth = 1.5
        passwordText = UITextField(frame: CGRect(origin: CGPoint(x: 20, y: 100), size: CGSize(width: 200, height: 20)))
        passwordText?.placeholder = "Insert password"
        passwordText?.borderStyle = .roundedRect
        passwordText?.layer.borderColor = UIColor.black.cgColor
        passwordText?.layer.borderWidth = 1.5
        
        loginButton = UIButton(frame: CGRect(origin: CGPoint(x: 20, y: 200), size: CGSize(width: 150, height: 20)))
        loginButton?.titleLabel?.adjustsFontSizeToFitWidth = true
        loginButton?.setTitleColor(UIColor.black, for: .normal)
        loginButton?.setTitle("Login", for: .normal)
        loginButton?.backgroundColor = UIColor.lightGray
        loginButton?.addTarget(self, action: #selector(buttonAction), for: .touchUpInside)
        
        if let label = usernameLabel {
            self.addSubview(label)
        }
        if let label = passwordLabel {
            self.addSubview(label)
        }
        if let text = usernameText {
            self.addSubview(text)
        }
        if let text = passwordText {
            self.addSubview(text)
        }
        if let button = loginButton{
            self.addSubview(button)
        }
        
        self.backgroundColor = UIColor.white
    }
    
    // Ovaj init se poziva kada se CustomView inicijalizira iz .xib datoteke
    required init?(coder aDecoder: NSCoder) {
        correct = 0
        super.init(coder: aDecoder)
        
        usernameLabel = UILabel(frame: CGRect(origin: CGPoint(x: 20, y: 20), size: CGSize(width: 280, height: 20)))
        usernameLabel?.text = "Username:"
        usernameLabel?.adjustsFontSizeToFitWidth = true
        usernameLabel?.backgroundColor = UIColor.white
        
        passwordLabel = UILabel(frame: CGRect(origin: CGPoint(x: 20, y: 100), size: CGSize(width: 100, height: 20)))
        passwordLabel?.text = "Password:"
        passwordLabel?.adjustsFontSizeToFitWidth = true
        passwordLabel?.backgroundColor = UIColor.white
        
        usernameText = UITextField(frame: CGRect(origin: CGPoint(x: 20, y: 40), size: CGSize(width: 200, height: 20)))
        usernameText?.borderStyle = .roundedRect
        usernameText?.placeholder = "Insert username"
        usernameText?.layer.borderColor = UIColor.black.cgColor
        usernameText?.layer.borderWidth = 1.5
        passwordText = UITextField(frame: CGRect(origin: CGPoint(x: 20, y: 70), size: CGSize(width: 200, height: 20)))
        passwordText?.placeholder = "Insert password"
        passwordText?.borderStyle = .roundedRect
        passwordText?.layer.borderColor = UIColor.black.cgColor
        passwordText?.layer.borderWidth = 1.5
        
        loginButton = UIButton(frame: CGRect(origin: CGPoint(x: 20, y: 200), size: CGSize(width: 135, height: 20)))
        loginButton?.titleLabel?.adjustsFontSizeToFitWidth = true
        loginButton?.setTitleColor(UIColor.black, for: .normal)
        loginButton?.setTitle("Login", for: .normal)
        loginButton?.backgroundColor = UIColor.lightGray
        loginButton?.addTarget(self, action: #selector(buttonAction), for: .touchUpInside)
        
        if let label = usernameLabel {
            self.addSubview(label)
        }
        if let label = passwordLabel {
            self.addSubview(label)
        }
        if let text = usernameText {
            self.addSubview(text)
        }
        if let text = passwordText {
            self.addSubview(text)
        }
        if let button = loginButton{
            self.addSubview(button)
        }
        
        self.backgroundColor = UIColor.white
    }
    
    @objc func buttonAction(_ sender: UIButton!){
        sender.backgroundColor = UIColor.yellow
        usernameText?.text = "Presseded Login"
        passwordText?.text = "U go gurl"
        correct = 1
        self.removeFromSuperview()
    }
}
