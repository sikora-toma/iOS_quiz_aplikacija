//
//  QuizTableViewCell.swift
//  0dz
//
//  Created by Toma Sikora on 07/05/2019.
//  Copyright © 2019 Toma Sikora. All rights reserved.
//

import UIKit

class QuizTableViewCell: UITableViewCell {
    
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!
    @IBOutlet weak var quizImageView: UIImageView!
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        if titleLabel != nil && descriptionLabel != nil {
            titleLabel.font = UIFont.systemFont(ofSize: 18)
            titleLabel.textColor = UIColor.black
            descriptionLabel.font = UIFont.systemFont(ofSize: 16)
            descriptionLabel.textColor = UIColor.gray
            descriptionLabel.numberOfLines = 10
        }
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        titleLabel.text = ""
        descriptionLabel.text = ""
        //quizImageView?.image = nil
    }
    
    func setup(quiz: Quiz){
        let quizService = QuizService()
        titleLabel.text = quiz.title
        descriptionLabel.text = quiz.description
        print(quiz.title)
        quizService.fetchImage(imageURL: (quiz.imageURL), completion: { (image) in
            DispatchQueue.main.async {
                self.quizImageView.image = image
                self.quizImageView.backgroundColor = quiz.category.UIcolour
            }
        })
    }
}
