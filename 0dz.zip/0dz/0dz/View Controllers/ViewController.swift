//
//  ViewController.swift
//  0dz
//
//  Created by Toma Sikora on 10/04/2019.
//  Copyright © 2019 Toma Sikora. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var QuizNameLabel: UILabel!
    
    @IBOutlet weak var FailLabel: UILabel!
    
    @IBOutlet weak var QuizImage: UIImageView!
    @IBOutlet weak var FunFactLabel: UILabel!
    
    @IBOutlet weak var QuestionViewContainer: UIView!
    @IBOutlet weak var LoginViewContainer: UIView!
    
    var quizzes: [Quiz] = []
    var qDict: [String: [Any]] = [:]
    var questions: [Question] = []
    var fetched = false
    let urlString = "https://iosquiz.herokuapp.com/api/quizzes"
    var QV: QuestionView = QuestionView(frame: CGRect(origin: CGPoint(x: 10, y: 10), size: CGSize(width: 300, height: 100)))
    var LV: LoginView = LoginView(frame: CGRect(origin: CGPoint(x: 10, y: 10), size: CGSize(width: 300, height: 700)))
    
    override func viewDidLoad() {
        super.viewDidLoad()
        LoginViewContainer.addSubview(LV)
    }
    
    @IBAction func Dohvati(_ sender: UIButton) {
        if LV.correct == 1 {
            LoginViewContainer.removeFromSuperview()
            let quizService = QuizService()
            QuestionViewContainer.addSubview(QV)
            quizService.fetchQuizzes(urlString: urlString)
            {(json) in
                if let json = json {
                            if let qDict = (json as? [String: Any])?["quizzes"] as? [[String: Any]] {
                                var i = 0
                                while i<qDict.count{
                                    self.quizzes.append(Quiz(quiz: qDict[i])!)
                                    i += 1
                                }
                            }
            
    //          Pronađi nba
                    if self.fetched == false {
                        quizService.findNBAinQuizzes(quizzes: self.quizzes, completion:
                            {(n) in
                                DispatchQueue.main.async {
                                    self.QuizNameLabel.text = "QuizName"
                                    self.FunFactLabel.text = "Riječ NBA je nađena " + String(n!) + " puta"
                                    self.fetched = true
                                }
                        })
                    }
                
    //          Odaberi quiz, postavi jedno pitanje u questionview i postavi UIImage
                    if let chosen = self.quizzes.randomElement() {
                        if let c = chosen.questions.randomElement() {
                            self.QV.setQ(question: c)
                        
                            quizService.fetchImage(imageURL: (chosen.imageURL), completion: { (image) in
                                DispatchQueue.main.async {
                                    self.QuizNameLabel.text = chosen.title
                                    self.QuizImage.isHidden = false
                                    self.QuizImage.alpha = 1
                                    self.QuizImage.image = image
                                    self.QuizImage.backgroundColor = chosen.category.UIcolour
                                    self.QuizNameLabel.textColor = chosen.category.UIcolour
                                }
                            })
                        }
                    }
                }
            }
        }
    }
}

