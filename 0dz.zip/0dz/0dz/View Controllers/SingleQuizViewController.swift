//
//  SingleQuizViewController.swift
//  0dz
//
//  Created by Toma Sikora on 05/05/2019.
//  Copyright © 2019 Toma Sikora. All rights reserved.
//

import UIKit

class SingleQuizViewController: UIViewController {

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var imageView: UIImageView!
    
    var quiz: Quiz? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()
        titleLabel.text = quiz?.title
        QuizService().fetchImage(imageURL: (quiz!.imageURL), completion: { (image) in
            DispatchQueue.main.async {
                self.imageView.image = image
                self.imageView.backgroundColor = self.quiz!.category.UIcolour
            }
        })
    }
}
