//
//  QuizzesViewController.swift
//  0dz
//
//  Created by Toma Sikora on 05/05/2019.
//  Copyright © 2019 Toma Sikora. All rights reserved.
//

import UIKit

class QuizzesViewController: UIViewController {
  
    @IBOutlet weak var tableView: UITableView!
    
    var quizzes: [Quiz] = []
    let urlString = "https://iosquiz.herokuapp.com/api/quizzes"
        
    var refreshControl: UIRefreshControl!
    //var tableFooterView: ReviewsTableViewFooterView!
    
    let cellReuseIdentifier = "cellReuseIdentifier"
    
    override func viewDidLoad() {
        super.viewDidLoad()

        setupTableView()
        setupData()
    }
    
    func setupTableView() {
        tableView.backgroundColor = UIColor.white
        tableView.delegate = self
        tableView.dataSource = self
        tableView.separatorStyle = .none
        
        refreshControl = UIRefreshControl()
        refreshControl.addTarget(self, action: #selector(QuizzesViewController.refresh), for: UIControl.Event.valueChanged)
        tableView.refreshControl = refreshControl

        tableView.register(UINib(nibName: "QuizTableViewCell", bundle: nil), forCellReuseIdentifier: cellReuseIdentifier)
        
//        tableFooterView = ReviewsTableViewFooterView(frame: CGRect(x: 0, y: 0, width: tableView.frame.width, height: 200))
//        tableFooterView.delegate = self
//        tableView.tableFooterView = tableFooterView
    }
    
    func setupData() {
//        QuizService().fetchQuizzes(urlString: urlString) { [weak self] (quizzes) in
//            self?.quizzes = quizzes as? [Quiz]
//            self?.refresh()
//        }
        QuizService().fetchQuizzes(urlString: urlString)
        {(json) in
            if let json = json {
                if let qDict = (json as? [String: Any])?["quizzes"] as? [[String: Any]] {
                    var i = 0
                    while i<qDict.count{
                        self.quizzes.append(Quiz(quiz: qDict[i])!)
                        print(self.quizzes[i])
                        i += 1
                    }
                }
            }
            self.refresh()
        }
    }
    
    @objc func refresh() {
        DispatchQueue.main.async {
            self.tableView.reloadData()
            self.refreshControl.endRefreshing()
        }
    }
    
    func quiz(atIndex index: Int) -> Quiz? {
        if quizzes.isEmpty {
            return nil
        }
        
        return quizzes[index]
    }
    
    func numberOfQuizzes() -> Int {
        return quizzes.count
    }
}

extension QuizzesViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150.0
    }
//popravi
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let view = QuizzesTableSectionHeader()
        return view
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 50.0
    }
//napisi skriptu singleQuizViewController
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)

        if let quiz = quiz(atIndex: indexPath.row) {
            let singleQuizViewController = SingleQuizViewController()
            singleQuizViewController.quiz = quiz
            navigationController?.pushViewController(singleQuizViewController, animated: true)
        }
    }
}

extension QuizzesViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: cellReuseIdentifier, for: indexPath) as! QuizTableViewCell
        
        if let quiz = quiz(atIndex: indexPath.row) {
            cell.setup(quiz: quiz)
        }
        return cell
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return numberOfQuizzes()
    }
}

//extension QuizzesViewController: TableViewFooterViewDelegate {
//    func quizCreated(withText title: String, date: String, summary: String) {
//        createQuiz()
//        tableView.insertRows(at: [IndexPath(row: numberOfReviews()-1, section: 0)], with: UITableView.RowAnimation.automatic)
//
//    }
//}
